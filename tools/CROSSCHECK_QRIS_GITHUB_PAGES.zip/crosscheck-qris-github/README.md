# Crosscheck QRIS V2HIM — GitHub Pages

Website statis untuk mencocokkan empat file Excel/CSV **MAIN V2HIM**, **ADM**, **P2M**, dan **DOCS**. Semua proses dilakukan **di browser**; file transaksi tidak diunggah ke server atau GitHub.

## Pasang di GitHub Pages
1. Buat repository baru di GitHub, misalnya `crosscheck-qris`.
2. Unggah file `index.html`, `style.css`, dan `app.js` ke **root** repository. Jangan unggah file transaksi atau data pelanggan.
3. Buka **Settings → Pages → Build and deployment**, pilih **Deploy from a branch**.
4. Pilih branch `main`, folder `/ (root)`, kemudian **Save**.
5. Buka alamat GitHub Pages yang muncul. Tunggu deployment selesai.

## Penggunaan
1. Unggah file ekspor MAIN, ADM, P2M dan DOCS (xlsx/xls/csv).
2. Klik **CEK SEMUA LIT**.
3. Periksa ringkasan, detail transaksi, serta tabel selisih ADM.
4. Klik **EKSPOR EXCEL** untuk laporan empat sheet.

## Format dan aturan
- **MAIN**: file Excel ekspor dengan dua baris header `TANGGAL/PROVIDER/...` dan `ORDER/IDN/WD/...`; filter `wecaaqris9`/`V2HIM`/`V2MIH`; transaksi XPAY diabaikan.
- **ADM**: CSV `Tanggal Terima, User, Action, Dari Bank, Tujuan Bank, Jumlah, Status, Operator`; filter `wecaaqris9` dan `ACCEPT`.
- **P2M**: CSV/XLSX berkolom `External Order ID`, `Total`, `Status`. Sufiks `--1`, `--2` dicocokkan ke LIT dasar dan jumlah nominal diakumulasi.
- **DOCS**: LIT di kolom **C** dan nilai koreksi di kolom **G**; format `(101,000)` dibaca **-101000**.
- Status **Validasi Success / IDN Failed / WD Failed** tidak wajib ADM, P2M, atau Docs.
- Status **Validasi Success / IDN Success / WD Failed** wajib ADM, tidak diharapkan terpotong P2M, wajib Docs.
- Status **Validasi Success / IDN Success / WD Success**, dengan nomor WD terisi, wajib ADM, diharapkan terpotong P2M, tanpa Docs.
- **WD kosong** tetap diperiksa khusus, tidak dipaksakan sebagai normal.
- **P2M REJECTED** selalu wajib koreksi Docs. Bila P2M APPROVED dan REJECTED bersamaan untuk LIT sama, sistem menandai konflik.
- Main↔ADM dihitung berdasarkan **User ID + nominal**; nomor/nama tujuan digunakan sebagai informasi validasi. Dengan beberapa transaksi identik dan waktu/urutan tidak pasti, tidak mungkin memastikan LIT hilang secara unik; aplikasi menampilkan daftar kandidat.

## Batasan audit
- Pastikan **keempat data menggunakan rentang tanggal/periode yang sesuai**. Rekap bisa meleset jika terdapat transaksi yang baru tercatat pada hari berikutnya.
- Selisih ADM adalah selisih **jumlah baris per kelompok**, bukan bukti LIT tertentu hilang.
- File P2M harus ekspor mutasi untuk jalur V2HIM yang sama, dan pengecualian lain perlu investigasi.
- Perhitungan nominal P2M tidak memperhitungkan biaya/top-up di luar data transaksi; saldo aktual tetap harus direkonsiliasi terpisah.
- Kode pihak ketiga pembaca Excel (`SheetJS`) dimuat dari `cdn.jsdelivr.net`; koneksi internet dibutuhkan untuk memuat library itu. Tidak ada permintaan upload data.

## Keamanan
Gunakan repository tanpa data transaksi; jangan simpan CSV pelanggan atau file hasil crosscheck pada GitHub publik. Jika ingin seluruh aplikasi bebas ketergantungan CDN, pustaka pembaca Excel perlu di-host sendiri setelah meninjau lisensinya.
